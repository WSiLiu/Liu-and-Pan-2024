function brightnessconstrast(bottomgray,N_cue)

s1 = [50,50];
s2 = [20,20];
bottomgray1 = (1-bottomgray) - bottomgray;
dd = abs(0.45 - bottomgray)/N_cue;
for ii = 1:1
    if ii == 1
      Retinalganglionneruon(zeros(s1));
    end
    for jj = 1:N_cue
    clear I0;
    ii1 = 1;
    bottomgray+(jj-1)*bottomgray1
    I0 = (bottomgray+(jj-1)*bottomgray1)*ones(s1);
    for m = ((s1(1)-s2(1))/2):(s2(1)+((s1(1)-s2(1))/2))
       for n = ((s1(2)-s2(2))/2):(s2(2)+((s1(2)-s2(2))/2))
           I0(m,n) = 0.5;
       end
    end
    
    I(:,:,ii,jj,ii1) = I0;
    figure;
    imshow(I(:,:,ii,jj,ii1));
    end

end


bio_retinal_rate_constr = struct;
clear name1;clear retinal_para_right;
name1 = 'retinal_para_right.mat';
retinal_para_right = load(name1);
N_retinal = size(retinal_para_right.retinal_para.sample.sig_center,1);
rate_retinal = zeros(N_retinal,2);
for ii = 1:1
    for jj = 1:N_cue
    for ii1 = 1:1
        
    f1 = I(:,:,ii,jj,ii1);
    clear name2;clear retinal_para_left;
    name2 = 'retinal_para_left.mat';
    retinal_para_left =load(name2);
    N_retinal = size(retinal_para_left.retinal_para.sample.sig_center,1);
    for n_retinal = 1:N_retinal
        rate_retinal(n_retinal,2) = 0;
        center_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,1:2);
        surround_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,3:4);
        center_sig = retinal_para_left.retinal_para.sample.sig_center(n_retinal,1);
        center_sigma = [center_sig,0;0,center_sig];
        surround_sig = retinal_para_left.retinal_para.sample.sig_surround(n_retinal,1);
        surround_sigma = [surround_sig,0;0,surround_sig];
        k1 = retinal_para_left.retinal_para.sample.k(n_retinal,1);
        for n_x = 1:size(f1,2)
            for n_y = 1:size(f1,1)
                if f1(n_y,n_x)~=0
                p = mvnpdf([n_y,n_x],center_mean,center_sigma)-k1*mvnpdf([n_y,n_x],surround_mean,surround_sigma);
                rate_retinal(n_retinal,2) = rate_retinal(n_retinal,2)+p*f1(n_y,n_x);
                end
            end
        end
    end
    clear name1;
    name1 = ['time',num2str(ii),num2str(jj),num2str(ii1)];
    bio_retinal_rate_constr = setfield(bio_retinal_rate_constr,name1,rate_retinal);
    end

    end
end


save 'bio_retinal_rate_constr.mat' -struct bio_retinal_rate_constr;
end