function neural_assemble(test_data,net,stimulus,j,L,T1)
%% Calculting downstream neural spiking rates for each situation
T = T1/2;
j = 1;clear Z_cout1;% cout1 for neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    
    for l = 1:L
    
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T-T1) = 1;
              end
      end
    end
    Z_cout1(:,:,l,l_style) = Z;
    
    end
    j = 1+j;
end
j = 1;clear Z_cout2;% cout2 for neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   
   for l = 1:L
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T1) = 1;
              end
      end
    end
    Z_cout2(:,:,l,l_style) = Z;
   end
j = 1+j;
end


%% reaction time
clear RT_mu;clear RT_std;figure;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time
  iden_time = net.iden_t(m1,3:end);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end
errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 5]);ylim([-5 50]);
set (gca,'xtick',[1:1:size(stimulus,2)]);

top1 = max(net.iden_t(:));top2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['situation',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
end
ylim([0 top2]);legend(name1);



%% For each downstream neuron, its responsivity is calculated through a Wilcoxon rank-sum test as one attribution
Z_spiketrain_real_avesimul = sum(Z_cout1,2);
NeuralrespPCA = Z_spiketrain_real_avesimul;
save('NeuralrespPCA1','NeuralrespPCA');
Z_spiketrain_pe_aversimul = sum(Z_cout2,2);
Z_spiketrain_Wilcoxon_test2 = zeros(size(Z_spiketrain_real_avesimul,1),size(Z_spiketrain_real_avesimul,4));
for nn = 1:size(Z_spiketrain_real_avesimul,1)
    for mm = 1:size(Z_spiketrain_real_avesimul,4)
    
    clear a;clear b;
     a = Z_spiketrain_real_avesimul(nn,1,:,mm);
     b = Z_spiketrain_pe_aversimul(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     Z_spiketrain_Wilcoxon_test2(nn,mm) = h;
    end
    
end



%% For each pair of downstream neurons, their responding similarity is calculated through the normalized mutual informaiton as one attribtuion
Z_spiketrain_real_avesimul = sum(Z_cout1,2);
Z_spiketrain_pe_aversimul = sum(Z_cout2,2);
Res = [];Res2 = [];
for mm = 1:size(Z_spiketrain_real_avesimul,4)% for each situaion��spiking counts of each neuron is measured over situations
    for nn = 1:size(Z_spiketrain_real_avesimul,1)
        Res = Z_spiketrain_real_avesimul(nn,1,:,mm);
        Res2(nn,:,mm) = Res(:)';
    end 
end

bottom1 = min(Res2(:));top1 = max(Res2(:));edge = (bottom1-0.5):1:(top1+0.5);% range of neural spiking counts
MI = zeros(1,1);
NMI = zeros(1,1);
Variab_prob = cell(1,1);

for mm = 1:size(Z_spiketrain_real_avesimul,4) % for each situaion, entropy and MI of neural responses are measured
    for nn = 1:size(Z_spiketrain_real_avesimul,1)
        for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
            x = Res2(nn,:,mm);
            x = x(:);
            y = Res2(nn1,:,mm);
            y = y(:);
            [mi, nmi] = mutual_info(x, y, edge);
            MI(nn,nn1,mm) = mi;
            NMI(nn,nn1,mm) = nmi;
        end
    end
end

edges = [];% for each situation, determine the threthold of neural responding similarity
for mm = 1:size(Z_spiketrain_real_avesimul,4)
NMI1 = NMI(:,:,mm);
[num,bin] = hist(NMI1,500);
prob1 = num/sum(num);Thre_value = [];
 for nn1 = 1:length(prob1)
    c = sum(prob1(1:nn1));
    if c >= 0.5 % Thethold is the MI corresponds to the middle in the distribtuion
        Thre_value = bin(nn1);
        break
    end
 end
 edges(:,:,mm) = double(NMI(:,:,mm) >= Thre_value);
end

% attributions for neural assembles
Attribu = [];
for mm = 1:size(Z_spiketrain_real_avesimul,4)
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            if nn2 == nn1
                Attribu(nn1,nn2,mm) = 1;
            else
                Attribu(nn1,nn2,mm) = edges(nn1,nn2,mm);
            end
        end
        Attribu(nn1,size(Z_spiketrain_real_avesimul,1)+1,mm) = Z_spiketrain_Wilcoxon_test2(nn1,mm);
    end
end
D = [];% D  relfect the divergence between neurons

for mm = 1:size(Z_spiketrain_real_avesimul,4)
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            D(nn1,nn2,mm) = sum(abs(Attribu(nn1,:,mm)-Attribu(nn2,:,mm)));
        end
    end
end
% given the numble of neural assembles as P, select P neurons withe the
% largest divergences
Initial_assemble = [];d1 = 0;
for mm = 1:size(Z_spiketrain_real_avesimul,4)
    d1 = 0;
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            for nn3 = 1:size(Z_spiketrain_real_avesimul,1)
                if (nn1~=nn2)&&(nn2~=nn3)&&(nn1~=nn3)
                d2 = [D(nn1,nn2,mm) D(nn1,nn3,mm) D(nn2,nn3,mm)];
                d1 = max(d1,mean(d2));
                if d1 == mean(d2)
                    1;
                    Initial_assemble(:,mm) = [nn1 nn2 nn3];
                end
                end
            end
        end
    end
end
neural_assemble = [];d1 = 0;
for mm = 1:size(Z_spiketrain_real_avesimul,4)
    neural_assemble(:,1,mm) = Initial_assemble(:,mm);
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        if isempty(find(nn1 == neural_assemble(:,:,mm),1))
            d1 = zeros(size(neural_assemble,1),1);nn = [];
            for nn2 = 1:size(neural_assemble,1)
                bb = neural_assemble(nn2,:,mm);
                bb = bb(bb>0);
                for nn3 = 1:length(bb)
                    d1(nn2,1) = d1(nn2,1) + D(nn1,nn3,mm);
                end
                d1(nn2,1) = d1(nn2,1)/length(bb);
            end
            nn = find(d1 == min(d1),1);
            bb3 = neural_assemble(nn,:,mm);
            bb3 = bb3(bb3>0);
            neural_assemble(nn,length(bb3)+1,mm) = nn1;
        end
    end
end

shape = ['o','+','d'];%% For each situation, plot determined neural assembles
for m = 1:size(neural_assemble,3)
    subplot(2,2,m);
    n_neuron = 0;
 for x = 1:20
    for y = 1:10
        n_neuron = n_neuron + 1;
        [n_assembel,~] = find(n_neuron == neural_assemble(:,:,m));
        a = x;b = y;
        plot(a,b,shape(n_assembel),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.4);hold on;
    end
 end
 xlim([0 21]);ylim([0 11]);
end

n_neuron = [];
for mm = 1:size(neural_assemble,3)
    for n_assemble = 1:3
       n_neuron0 = neural_assemble(n_assemble,:,mm);
       n_neuron0 = n_neuron0(n_neuron0>0);
       n_neuron(mm,n_assemble) = length(n_neuron0);
    end
end
figure;h = bar(n_neuron);
for mm = 1:size(neural_assemble,3)
    h(mm).FaceColor = [mm*0.2 mm*0.2 mm*0.2];
end



%% calcuate contributions of neual assembles in causal inference

NeuralassemblContri = cell(size(NeuralrespPCA,4),1);
for nn = 1:size(NeuralrespPCA,4)
       Neuralresp0 = [];
       for n1 = 1:size(NeuralrespPCA,1)
           Neuralresp0(n1,:) = NeuralrespPCA(n1,1,:,nn);
       end
       
       a = Neuralresp0';
       b = cov(a);% b is co-variance matrix
       b1 = cov(b);
       [coeff, score, latent, tsquared, explained, mu] = pca(b);
       % coeff returns the principal component coefficients for the N by P data matrix X. Rows of X correspond to observations 
       % and columns to variables. Each column of COEFF contains coefficients
       % for one principal component. 
       % LATENT returns the principal component variances, i.e., the eigenvalues of the covariance matrix of X.

       for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90 % principal components explain 90% of variances are selected
               [n,c]
               N_PCA = n;%N_PCA is the number of principal components
               break
           end 
       end 
   
       [V,D] = eig(b1);
       eigvalue = diag(D);
       [~,idx] = sort(eigvalue,'descend');
       V1 = V(:,idx);
       eigvalue1 = eigvalue(idx);
       D1 = diag(eigvalue1);
   

       % contributions of each row in b are measured 
       radio0 = zeros(size(b,2),N_PCA);
   
       for n = 1:size(b,2) 
           for m = 1:N_PCA 
           clear t;clear lam;clear sig;
           t = coeff(n,m)^2;  
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t/sig;
           end
       
       end
       NeuralassemblContri{nn,1} = radio0;
end
%% For each situation��calculate contributions of neural assembles
Neural_assemb_contri = zeros(size(neural_assemble,3),size(neural_assemble,1));
for m = 1:size(neural_assemble,3)
    for n_assemble = 1:size(neural_assemble,1)
        neuron = [];neural_assemb_contri = [];
        neuron = neural_assemble(n_assemble,:,m);
        neuron = neuron(:);
        neuron = neuron(neuron>0);
        neural_assemb_contri = NeuralassemblContri{m,1}(neuron,:);
        Neural_assemb_contri(m,n_assemble) = sum(neural_assemb_contri(:));
    end
    total = sum(Neural_assemb_contri(m,:));
    Neural_assemb_contri(m,:) = Neural_assemb_contri(m,:)./total;
end
figure;hold on;
h = bar(Neural_assemb_contri);
x = 1:size(neural_assemble,3);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:size(neural_assemble,3)
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
    xlim([0.5 size(neural_assemble,3)+0.5]);
end
%% calculate constritutions to different situations of each neuron
Neural_contri = [];
for n = 1:size(NeuralassemblContri{1,1},1)% n is the number of neuron
    neural_contri = [];
    for mm = 1:size(NeuralassemblContri,1)
       neural_contri = sum(NeuralassemblContri{mm,1}(n,:));
       Neural_contri(n,mm) = neural_contri;
    end
end
ID = [];
for mm = 1:size(NeuralassemblContri,1)
    
    neural_contri0 = Neural_contri(:,mm);
    [~,ID(:,mm)] = sort(neural_contri0,'descend');
end
neural_contri1 = [];
for mm = 1:size(NeuralassemblContri,1)
    for n = 1:size(NeuralassemblContri{1,1},1) 
        k = find(n == ID(:,mm),1);
        neural_contri1(mm,n) = k; 
    end
    clear neural_contri2;
    neural_contri2 = reshape(neural_contri1(mm,:),10,20);
    bottom1 = min(neural_contri2(:));top1 = max(neural_contri2(:));
    color1 = [];
    for l1 = 1:size(neural_contri2,1)
        for l2 = 1:size(neural_contri2,2)
               color1(l1,l2) = (neural_contri2(l1,l2) - bottom1)/(top1 - bottom1);
        end
    end
    figure;b = bar3(neural_contri2);
    for ll = 1:size(b,2)
        b(1,ll).FaceColor = 'white';
    end
end

%% For each situation, calculate time-varying contributions of neural assembles
NeuralassemblContri0 = cell(size(Z_cout1,4),size(Z_cout1,2));
for tt = 1:size(Z_cout1,2)
    Neuralresp = Z_cout1(:,tt,:,:);
    % NeuralassemblContri0 = cell(size(Neuralresp,4),1);
    for nn = 1:size(Neuralresp,4)
        Neuralresp0 = [];
        for n1 = 1:size(Neuralresp,1)
           Neuralresp0(n1,:) = Neuralresp(n1,1,:,nn);
        end
        a = Neuralresp0';
        b = cov(a);
        b1 = cov(b);
        [coeff, score, latent, tsquared, explained, mu] = pca(b);
        for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90
               [n,c]
               N_PCA = n;
               break
           end  
        end 
        b1 = cov(b);
        [V,D] = eig(b1);
        eigvalue = diag(D);
        [~,idx] = sort(eigvalue,'descend');
        V1 = V(:,idx);
        eigvalue1 = eigvalue(idx);
        D1 = diag(eigvalue1);
        radio0 = zeros(size(b,2),N_PCA);
        for n = 1:size(b,2) 
         for m = 1:N_PCA 
           clear t;clear lam;clear sig;
           t1 = coeff(n,m)^2;
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t1/sig;
         end
        end
     NeuralassemblContri0{nn,tt} = radio0;
    end
end

Neural_assemble_temporal_contri = cell(size(Z_cout1,4),1);
for nn = 1:size(Z_cout1,4)
    
    clear neural_assemble_temporal_contri2;
    for ll = 1:size(neural_assemble,1)
            neuron = neural_assemble(ll,:,nn);
            neuron = neuron(neuron>0);
            
            for t = 1:size(Z_cout1,2)
                clear neural_assemble_temporal_contri0;clear neural_assemble_temporal_contri1;
                neural_assemble_temporal_contri0 = NeuralassemblContri0{nn,t};
                neural_assemble_temporal_contri1 = neural_assemble_temporal_contri0(neuron(:),:);
                neural_assemble_temporal_contri2(ll,t) = sum(sum(neural_assemble_temporal_contri1,2));
            end
    end
    
    Neural_assemble_temporal_contri{nn,1} = neural_assemble_temporal_contri2;
    t1 = 1:1:size(Z_cout1,2);
    figure;
    for k1 = 1:size(neural_assemble_temporal_contri2,1)
        plot(t1,neural_assemble_temporal_contri2(k1,:),'color',[0.25 0.25 0.25]*k1);hold on;
    end
    legend('assemble 1','assemble 2','assemble 3');
end


end