function eval_mem_task_collect( ex_path1,num_trials,state,T,stimulus,src_file_name1,src_file_name2,varargin )

[num_trials, ...
      dt, ...
      sigm, ...
      test_data_generator, ...
      free_data_generator, ...
      eval_second_half_only, ...
      r_min ] = snn_process_options( varargin, ...
                                        'num_trials', num_trials, ...
                                        'dt', 0.001, ...
                                        'sigma', 0.01, ...
                                        'test_data_generator', [], ...
                                        'free_data_generator', [], ...
                                        'eval_second_half_only', false, ...
                                        'r_min', [] );

dt = 0.001; sigm = 0.01;r_min = [];eval_second_half_only = 0;
num_patterns = length(stimulus);
data = load( src_file_name1 );
st = data.sim_test{1}.time(1);
samples = st:dt:data.sim_test{1}.time(end);
pat_labels = { data.train_set_generator.pat_labels{:}};
data = load( src_file_name2 );
num_trials = size(data.test_data,2);
num_seqs = 1;

save_file = [ ex_path1,'firingrate', num2str(num_trials),'.mat'];
old_verbose_option = snn_options( 'verbose', false );
net = snn_set( data.net );
net.state = snn_set( data.net );
fil = inline('exp( -((x-mu).^2)./(2*sigma^2) )', 'x', 'mu', 'sigma');

peth_top_test = cell(num_seqs,1);
peth_bio_test = cell(num_seqs,1);
peth_left_test = cell(num_seqs,1);
peth_right_test = cell(num_seqs,1);
num_spikes_bio_test = zeros(net.num_bio_neurons,1);

    for seq_id = 1:num_seqs
        pat_labels{seq_id} = num2str(seq_id);
        cur_peth_bio = zeros( net.num_bio_neurons, length(samples) );
        for trial = 1:num_trials

            Zt = data.test_data{seq_id,trial}.Zt;
            Zt1 = zeros(2,1);
            l = 0;
            for t=1:size(Zt,2)
                for n = 1:size(Zt,1)
                    if Zt(n,t) == 1
                        l = l+1;
                        Zt1(1,l) = n;Zt1(2,l) = t;
                    end
                end
            end
            Zt1(2,:) = Zt1(2,:)/1000;
            data.test_data{seq_id,trial}.Zt1 = Zt1;
            
            for i = 1:size( Zt1,2)
                cur_peth_bio(Zt1(1,i),:);
                cur_peth_bio(Zt1(1,i),:) = cur_peth_bio(Zt1(1,i),:) + fil( samples, Zt1(2,i), sigm );%filtered firing rate of each neuron
                num_spikes_bio_test(Zt1(1,i)) = num_spikes_bio_test(Zt1(1,i),:) + 1;
            end
            peth_bio_test{seq_id} = cur_peth_bio;
            
        end
        
    end
    
    
    
     peth_bio_test_all = [peth_bio_test{:}];
     clear v_test;clear idx;clear Z;clear J;
     [v_test,idx] = max((peth_bio_test_all(:,(T+1):end))');
     
     
     idx( v_test < 1 ) = inf;
     [Y_bio,I_bio] = sort(idx);
     for seq_id = 1:num_seqs
        [v_test,idx] = max(peth_bio_test{seq_id}');
        max_firing_times_bio(seq_id,:) = idx*dt;
        [Z,J] = sort(idx);
        
        rank_test_bio{seq_id} = zeros(1,net.num_bio_neurons);
        
        
        rank_test_bio{seq_id} = 1:net.num_bio_neurons;
        rank_free{seq_id} = zeros(1,net.num_bio_neurons);        
        rank_free{seq_id} = 1:net.num_bio_neurons;
        
     end
     
     test_data = data.test_data;
     
     save( save_file, 'net', 'test_data', ... 
         'peth_bio_test', 'rank_test_bio', 'I_bio', 'num_spikes_bio_test', 'max_firing_times_bio', ...
         'state', '-v7.3');
end