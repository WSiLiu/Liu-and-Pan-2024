function [patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns1(stimulus,T,N_cue)
%%

pat_sequences = cell(1,1);
patterns = cell(1,1);
pat_labels = cell(1,1);
pat_seq = [];
R0 = [];
cue = [];
noisy_stren = 1/50; % stength of noisy signal

for n_stimulus = 1:length(stimulus)
    
    pat_seq0 = [];
    rate = [];
    
    clear bb1
    bb1 = 1 + double(n_stimulus>1);%In each training simulation, determine the type of the first stimulus in the paired images

    if bb1 == 1
                load('bio_retinal_rate_ori.mat'); % the fist stimulus in the first pair of images is ori stimulus
                name = 'bio_retinal_rate_ori.mat';
    else
                load('bio_retinal_rate_constr.mat'); % the fist stimulus in the first pair of images is brightness stimulus
                name = 'bio_retinal_rate_constr.mat';
    end
    for jj = 1:N_cue 
        cue1 = double(rand(1,1)>0.5); % determine the type of the second stimulus, randomly
        clear rate2;clear rate3;
        clear name1;% 
        name1 = ['time',num2str(1),num2str(1),num2str(1)];
        rate1 = cell2mat(struct2cell(load(name,name1)));
        for t = 1:T
            rate2(:,t) = rate1(:,2);
        end
         if cue1 == 1
            pat_seq0(jj,1) = 1;% pat_seq0 = 1 means the types are same
            clear name1;
            name1 = ['time',num2str(1),num2str(2),num2str(1)];
            rate1 = cell2mat(struct2cell(load(name,name1)));
            for t = 1:T
                rate3(:,t) = rate1(:,2);
            end
         else
            pat_seq0(jj,1) = 2;% pat_seq0 = 2 means the types are not same
            if bb1 == 1
                load('bio_retinal_rate_constr.mat');
                name = 'bio_retinal_rate_constr.mat';
            else
                load('bio_retinal_rate_ori.mat');
                name = 'bio_retinal_rate_ori.mat';
            end
            clear name1;clear rate1;
            name1 = ['time',num2str(1),num2str(2),num2str(1)];
            rate1 = cell2mat(struct2cell(load(name,name1)));
            for t = 1:T
                rate3(:,t) = rate1(:,2);
            end
         end
         pat_seq1 = max(pat_seq0(:));
         rate = [rate;rate2;rate3];
    end
    
    pat_seq = [pat_seq,pat_seq1];
    cue = [cue,pat_seq0];
    num_inputs = size(rate,1);
    r_duration =  noisy_stren*rand(size(rate,1),T);
    rate = [r_duration,rate];
    R0 = [R0,rate];
end
r_duration2 = zeros(size(rate,1),2*T);
R0 = [r_duration2,R0];
pat_seq = [(-1)*ones(size(pat_seq,1),1),pat_seq];% the cue of the blank duration is -1 and has no meaning
cue = [(-1)*ones(size(cue,1),1),cue]; % cue returns the sequence of values of cue
R0 = (R0.*double(R0>0))*(1/noisy_stren);
pat_sequences{1,1} = pat_seq;
patterns{1,1} = R0;
pat_labels{1,1} = num2str(1);
free_pat_sequences = pat_sequences;

name3 = 'patterns.mat';
name4 = 'pat_sequences.mat';
name5 = 'free_pat_sequences.mat';
name6 = 'pat_labels.mat';
name7 = 'num_inputs.mat';

save(name3,'patterns');
save(name4,'pat_sequences');
save(name5,'free_pat_sequences');
save(name6,'pat_labels');
save(name7,'num_inputs');
end