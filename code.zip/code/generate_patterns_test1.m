function [patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns_test1(stimulus,T,N_cue)

pat_sequences = cell(1,1);
patterns = cell(1,1);
pat_labels = cell(1,1);
pat_seq = [];
R0 = [];
cue = [];
noisy_stren = 1/50;

for n_stimulus = 1:length(stimulus)
    
    pat_seq0 = [];
    rate = [];
    
    jj = 1; 
         if n_stimulus == 1 % for the first situation, the first stimulus is ori and the stimuli have same types
                cue1 = 1;
                load('bio_retinal_rate_ori.mat');
                name = 'bio_retinal_rate_ori.mat';
                clear rate1;clear rate2;clear name1;
                name1 = ['time',num2str(1),num2str(1),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate2(:,t) = rate1(:,2);
                end
                clear rate1;clear rate3;clear name1;
                name1 = ['time',num2str(1),num2str(2),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate3(:,t) = rate1(:,2);
                end
                pat_seq0(jj,1) = 1;% pat_seq0 = 1 means the types are same
         elseif n_stimulus == 2% for the second situation, the first stimulus is brightness and the stimuli have same types
             
                cue1 = 1;
                load('bio_retinal_rate_constr.mat');
                name = 'bio_retinal_rate_constr.mat';
                clear rate1;clear rate2;clear name1;
                name1 = ['time',num2str(1),num2str(1),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate2(:,t) = rate1(:,2);
                end
                clear rate1;clear rate3;clear name1;
                name1 = ['time',num2str(1),num2str(2),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate3(:,t) = rate1(:,2);
                end
                pat_seq0(jj,1) = 1;% pat_seq0 = 1 means the types are same
             
         elseif n_stimulus == 3% for the first situation, the first stimulus is ori and the stimuli have different types
             
                cue1 = 2;
                load('bio_retinal_rate_ori.mat');
                name = 'bio_retinal_rate_ori.mat';  
                clear rate1;clear rate2;clear name1;
                name1 = ['time',num2str(1),num2str(1),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate2(:,t) = rate1(:,2);
                end
                load('bio_retinal_rate_constr.mat');
                name = 'bio_retinal_rate_constr.mat';
                clear rate1;clear rate3;clear name1;
                name1 = ['time',num2str(1),num2str(2),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate3(:,t) = rate1(:,2);
                end
                pat_seq0(jj,1) = 2;% pat_seq0 = 2 means the types are not same
         elseif n_stimulus == 4% for the second situation, the first stimulus is brightness and the stimuli have  types
             
                cue1 = 2;
                load('bio_retinal_rate_constr.mat');
                name = 'bio_retinal_rate_constr.mat';
                clear rate1;clear rate2;clear name1;
                name1 = ['time',num2str(1),num2str(1),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate2(:,t) = rate1(:,2);
                end
                load('bio_retinal_rate_ori.mat');
                name = 'bio_retinal_rate_ori.mat';
                clear rate1;clear rate3;clear name1;
                name1 = ['time',num2str(1),num2str(2),num2str(1)];
                rate1 = cell2mat(struct2cell(load(name,name1)));
                for t = 1:T
                  rate3(:,t) = rate1(:,2);
                end
                pat_seq0(jj,1) = 2;% pat_seq0 = 2 means the types are not same
             
         end
         
         pat_seq1 = max(pat_seq0(:));
         rate = [rate;rate2;rate3];
         
         [n_stimulus,jj];
         size(rate);
         pat_seq = [pat_seq,pat_seq1];
         cue = [cue,pat_seq0];
         r_duration =  noisy_stren*rand(size(rate,1),T);
         rate = [r_duration,rate];
         R0 = [R0,rate];
   
    
    
    num_inputs = size(rate,1);
    
    
end
r_duration2 = zeros(size(rate,1),2*T);
R0 = [r_duration2,R0];
pat_seq = [(-1)*ones(size(pat_seq,1),1),pat_seq];
cue = [(-1)*ones(size(cue,1),1),cue];
R0 = (R0.*double(R0>0))*(1/noisy_stren);
pat_sequences{1,1} = pat_seq;
patterns{1,1} = R0;
pat_labels{1,1} = num2str(1);
free_pat_sequences = pat_sequences;

name3 = 'patterns.mat';
name4 = 'pat_sequences.mat';
name5 = 'free_pat_sequences.mat';
name6 = 'pat_labels.mat';
name7 = 'num_inputs.mat';

save(name3,'patterns');
save(name4,'pat_sequences');
save(name5,'free_pat_sequences');
save(name6,'pat_labels');
save(name7,'num_inputs');
end