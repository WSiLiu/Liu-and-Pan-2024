%% 1 [One cue]

clear all;clc;
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();

T0 = 100;
stimulus0 = 1:2;
stimulus1 = 1:4;
bottomgray = 0.2;
N_cue = 1;
T = T0;


brightnessconstrast(bottomgray,2);
ori_stimulus2(T,2)

T = T0;
stimulus = stimulus0;

clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns1(stimulus,T/2,N_cue);

state = 'movement';
num_bio_neurons = 200;
num_train_sets = 500;
num_trials0 = 500;

tic;
T
[ex_path1,patterns] = do_learning_task_stereomovement1( 'results/', ...
                  pat_sequences, ... 
                  default_params{:}, ...
                  'pattern_length', size(patterns{1,1},2),...
                  'free_run_seqs',  free_pat_sequences , ... 
                  'pat_labels', pat_labels, ...
                  'free_run_pat_lenghts', size(patterns{1, 1},2), ...
                  'num_bio_neurons', num_bio_neurons, ...             % number of WTA neurons
                  'num_inputs', num_inputs, ...              % number of afferent neurons
                  'free_run_time', size(patterns{1,1},2), ...         % free run time (s)
                  'save_interval', (num_train_sets-1), ...           % number of iterations between 2 save files
                  'num_train_sets', num_train_sets, ...        % number of training iterations
                  'collect', '[At,R]', ...
                  'num_epochs', 1, ...
                  'patterns', patterns, ...
                  'sample_method', 'ctrfstere', ...
                  'state',state, ...
                  'T', T, ...
                  'stimulus', stimulus, ...
                  'N_cue',N_cue,...
                  'cue', cue, ...
                  'changelog_flag', 'N' );
toc;

% ex_path1 = ex_path1;save('ex_path1','ex_path1');
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();
state = 'movement';

stimulus = stimulus1;
num_trials = num_trials0;
clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns_test1(stimulus,T/2,N_cue);

eval_mem_task_steremovement1(ex_path1,num_trials,state,T,stimulus,N_cue,cue);
% ex_path1 = load('ex_path1');ex_path1 = ex_path1.ex_path1;
name1 = ['data_set_00000',num2str(num_train_sets-1),'.mat'];
src_file_name1 = [ex_path1,name1];
%src_file_name1 = [ex_path1,'data_set_00000299.mat'];
name2 = ['mem_task_test',num2str(num_trials),'.mat'];
src_file_name2 = [ex_path1,name2];
%src_file_name2 = [ex_path1,'mem_task_test100.mat'];
eval_mem_task_steremovement1_1( ex_path1,num_trials,state,T,stimulus,src_file_name1,src_file_name2 )
1
% ex_path1 = load('ex_path1');ex_path1 = ex_path1.ex_path1;
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();
state = 'movement';
stimulus = stimulus1;
num_trials = num_trials0;
T0 = 100;
T = T0;
bottomgray = 0.2;
path = [ex_path1,'mem_task_test',num2str(num_trials),'.mat'];
load(path);
j = 1;L = size(test_data,2);
neural_assemble1(test_data,stimulus,j,L,T);
%% 2 [Two cue]
clear all;clc;
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();

T0 = 100;
stimulus0 = 1:2;
bottomgray = 0.2;
N_cue = 2;
T = T0;
num_trials0 = 100;

brightnessconstrast(bottomgray,N_cue);
ori_stimulus2(T,N_cue)

T = T0;
stimulus = stimulus0;

clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns2(stimulus,T/2,N_cue);

state = 'movement';
num_bio_neurons = 200;
num_train_sets = 500;

tic;
[ex_path2,patterns] = do_learning_task_stereomovement2( 'results/', ...
                  pat_sequences, ... 
                  default_params{:}, ...
                  'pattern_length', size(patterns{1,1},2),...
                  'free_run_seqs',  free_pat_sequences , ... 
                  'pat_labels', pat_labels, ...
                  'free_run_pat_lenghts', size(patterns{1, 1},2), ...
                  'num_bio_neurons', num_bio_neurons, ...             % number of WTA neurons
                  'num_inputs', num_inputs, ...              % number of afferent neurons
                  'free_run_time', size(patterns{1,1},2), ...         % free run time (s)
                  'save_interval', (num_train_sets-1), ...           % number of iterations between 2 save files
                  'num_train_sets', num_train_sets, ...        % number of training iterations
                  'collect', '[At,R]', ...
                  'num_epochs', 1, ...
                  'patterns', patterns, ...
                  'sample_method', 'ctrfstere', ...
                  'state',state, ...
                  'T', T, ...
                  'stimulus', stimulus, ...
                  'N_cue',N_cue,...
                  'cue', cue, ...
                  'changelog_flag', 'N' );
toc;

% ex_path2 = ex_path2;save('ex_path2','ex_path2');
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();
state = 'movement';
stimulus = stimulus0;
num_trials = num_trials0;
clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns_test2(stimulus,T/2,N_cue);

eval_mem_task_steremovement2(ex_path2,num_trials,state,T,stimulus,N_cue,cue);

% ex_path2 = load('ex_path2');ex_path2 = ex_path2.ex_path2;
src_file_name1 = [ex_path2,'data_set_00000499.mat'];
src_file_name2 = [ex_path2,'mem_task_test100.mat'];
eval_mem_task_steremovement1_1( ex_path2,num_trials,state,T,stimulus,src_file_name1,src_file_name2 )
1
% ex_path2 = load('ex_path2');ex_path2 = ex_path2.ex_path2;
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();
state = 'movement';
stimulus = [1 2];
num_trials = num_trials0;
T0 = 100;
T = T0/2;
bottomgray = 0.2;
path = [ex_path2,'mem_task_test',num2str(num_trials),'.mat'];
load(path);
j = 1;L = size(test_data,2);
neural_assemble(test_data,stimulus,j,L,T);


