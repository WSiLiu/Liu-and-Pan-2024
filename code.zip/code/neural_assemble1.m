function neural_assemble1(test_data,stimulus,j,L,T)
%% �����������µڶ�����Ԫ��ƽ��˲ʱ�ŵ��ʡ�
T1 = T;
T = T/2;
j = 1;clear Z_cout1;% cout1 for real;
for l_style = 1:size(stimulus,2)
    j
    [(T1+(j-1)*2*T+T+1),(T1+(j-1)*2*T+T+T)]
    for l = 1:L
    
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T-T1) = 1;
              end
      end
    end
    Z_cout1(:,:,l,l_style) = Z;
    
    end
    j = 1+j;
end
j = 1;clear Z_cout2;% cout2 for pre;
for l_style = 1:size(stimulus,2)
   j
   [(T1+(j-1)*2*T+1),(T1+(j-1)*2*T+T)]
   for l = 1:L
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T1) = 1;
              end
      end
    end
    Z_cout2(:,:,l,l_style) = Z;
   end
j = 1+j;
end
% save('Z_cout1','Z_cout1');save('Z_cout2','Z_cout2');
Z_spikecount_real = mean(Z_cout1,3);
Z_spikecount_pe = mean(Z_cout2,3);
sig = 50;
Z_rate_real_Gauss = zeros(size(Z_spikecount_real,1),size(Z_spikecount_real,2),size(Z_spikecount_real,4));
Z_rate_pe_Gauss = zeros(size(Z_spikecount_pe,1),size(Z_spikecount_pe,2),size(Z_spikecount_pe,4));
for nn = 1:size(Z_spikecount_real,4)% Gaussian function filtered rate
    for n = 1:size(Z_spikecount_real,1)
     for t = 1:size(Z_spikecount_real,2)
        for t1 = 1:size(Z_spikecount_real,2)
            Z_rate_real_Gauss(n,t,nn) = Z_rate_real_Gauss(n,t,nn) + normpdf(t,t1,sig)*Z_spikecount_real(n,t1,1,nn);
            Z_rate_pe_Gauss(n,t,nn) = Z_rate_pe_Gauss(n,t,nn) + normpdf(t,t1,sig)*Z_spikecount_pe(n,t1,1,nn);
        end
     end
    end
end
clear Z_rate_real_Gauss_filtered;clear Z_rate_pe_Gauss_filtered;clear neural_sparse;clear neural_popul_sparse;
[Z_rate_real_Gauss_filtered,Z_rate_pe_Gauss_filtered,neural_sparse,neural_popul_sparse] = re_arrange_neuron(Z_rate_real_Gauss,Z_rate_pe_Gauss);
Z_rate_Gauss = [];
for nn = 1:size(Z_rate_pe_Gauss,3)
    Z_rate_Gauss = [Z_rate_Gauss,Z_rate_pe_Gauss_filtered(:,:,nn),Z_rate_real_Gauss_filtered(:,:,nn)];
end
Z_rate_Gauss = sort(Z_rate_Gauss);
% figure; hist(neural_sparse,20);
% figure; hist(neural_popul_sparse);

%% reaction time
clear RT_mu;clear RT_std;figure;%��������̼���RT�ľ�ֵ���׼��
for m1 = 1:size(stimulus,2)
  clear iden_time
  iden_time = net.iden_t(m1,3:end);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end
errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 5]);ylim([-5 50]);
set (gca,'xtick',[1:1:size(stimulus,2)]);

top1 = max(net.iden_t(:));top2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)%����ÿ���̼���RT��Ƶ�ʷֲ�
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['situation',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
end
ylim([0 top2]);legend(name1);



%% �Ƚϸ�����Ԫ�ڸ����̼���ʹ̼�ǰ�Ļ���죬��Ϊһ������
Z_spiketrain_real_avesimul = sum(Z_cout1,2);
NeuralrespPCA = Z_spiketrain_real_avesimul;
save('NeuralrespPCA1','NeuralrespPCA');
Z_spiketrain_pe_aversimul = sum(Z_cout2,2);
Z_spiketrain_Wilcoxon_test2 = zeros(size(Z_spiketrain_real_avesimul,1),size(Z_spiketrain_real_avesimul,4));
for nn = 1:size(Z_spiketrain_real_avesimul,1)
    for mm = 1:size(Z_spiketrain_real_avesimul,4)
    
    clear a;clear b;
     a = Z_spiketrain_real_avesimul(nn,1,:,mm);
     b = Z_spiketrain_pe_aversimul(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     Z_spiketrain_Wilcoxon_test2(nn,mm) = h;
    end
    
end



%% �ҵ������������ԪȺ�壬�Լ���ͬ����ԪȺ�塣
Z_spiketrain_real_avesimul = sum(Z_cout1,2);
Z_spiketrain_pe_aversimul = sum(Z_cout2,2);
Res = [];Res2 = [];
for mm = 1:size(Z_spiketrain_real_avesimul,4)%��ÿ���̼������������Ԫ���ظ�ģ���е��������
    for nn = 1:size(Z_spiketrain_real_avesimul,1)
        Res = Z_spiketrain_real_avesimul(nn,1,:,mm);
        Res2(nn,:,mm) = Res(:)';
    end 
end

bottom1 = min(Res2(:));top1 = max(Res2(:));edge = bottom1:1:top1;%ȷ���������ͳһ�ķ�Χ��
Entropy = cell(1,1);
Variab_prob = cell(1,1);
for mm = 1:size(Z_spiketrain_real_avesimul,4)%��ÿ���Ĵ̼��ظ�ģ�⣬���������Ԫ��ĸ��ʺ���
    for nn = 1:size(Z_spiketrain_real_avesimul,1)
        variabl_prob = [];
        [N,~] = histcounts(Res2(nn,:,mm),edge);
        variabl_prob = N./sum(N);
        variabl_prob = variabl_prob(variabl_prob>0);
        Variab_prob{nn,mm} = variabl_prob;
        Entropy{nn,nn,mm} = - sum(variabl_prob(:).*log2(variabl_prob(:)));
    end
end

Variab_jointprob = cell(1,1);
for mm = 1:size(Z_spiketrain_real_avesimul,4)%��ÿ���̼����ظ�ģ��,����ɶ���Ԫ������ϸ��ʷֲ�
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            joint_neural_res = zeros(length(edge),length(edge));
            if nn2 ~= nn1
            for ll = 1:size(Z_spiketrain_real_avesimul,3)
                a1 = Z_spiketrain_real_avesimul(nn1,1,ll,mm);% a1,b1��¼�˳ɶ���Ԫ������Ƶ��
                b1 = Z_spiketrain_real_avesimul(nn2,1,ll,mm);
                joint_neural_res(find(edge==a1,1),find(edge==b1,1)) = joint_neural_res(find(edge==a1,1),find(edge==b1,1)) + 1; 
            end
            N = sum(joint_neural_res(:));
            variabl_jointprob = joint_neural_res./N;
            variabl_jointprob = variabl_jointprob(variabl_jointprob>0);
            Variab_jointprob{nn1,nn2} = variabl_jointprob;
            end 
        end
    end
end
for mm = 1:size(Z_spiketrain_real_avesimul,4)%����ɶ���Ԫ���������
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            if nn2 ~= nn1
               variabl_jointprob = Variab_jointprob{nn1,nn2}(:);
               variabl_jointprob = variabl_jointprob(variabl_jointprob>0);
               Entropy{nn1,nn2,mm} = - sum(variabl_jointprob(:).*log2(variabl_jointprob(:)));
            end
        end
    end
end
% �����ش��ڵ�������Ķ����أ�ͬʱС�ڵ��ڶ�����֮�͡� https://baike.baidu.com/item/%E8%81%94%E5%90%88%E7%86%B5/22709235?fr=ge_ala
MI = [];NMI = [];
for mm = 1:size(Z_spiketrain_real_avesimul,4)%��ÿ���̼�������ɶ���Ԫ���MI��NMI
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            if nn2 ~= nn1
                MI(nn1,nn2,mm) = Entropy{nn1,nn1,mm} + Entropy{nn2,nn2,mm} - Entropy{nn1,nn2,mm};%https://baike.baidu.com/item/%E4%BA%92%E4%BF%A1%E6%81%AF/7423853
                NMI(nn1,nn2,mm) = MI(nn1,nn2,mm)/(Entropy{nn1,nn1,mm} + Entropy{nn2,nn2,mm});
            end
        end
    end
end

edges = [];
for mm = 1:size(Z_spiketrain_real_avesimul,4)
NMI1 = NMI(:,:,mm);%����NMI�ֲ����ȷ����ֵ,��ȷ����Ԫ��Ⱥ��
[num,bin] = hist(NMI1,500);
prob1 = num/sum(num);Thre_value = [];
 for nn1 = 1:length(prob1)
    c = sum(prob1(1:nn1));
    if c >= 0.5
        Thre_value = bin(nn1);
        break
    end
 end
 edges(:,:,mm) = double(NMI(:,:,mm) >= Thre_value);
end

%����ÿ����Ԫ��attributions
Attribu = [];
for mm = 1:size(Z_spiketrain_real_avesimul,4)
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            if nn2 == nn1
                Attribu(nn1,nn2,mm) = 1;
            else
                Attribu(nn1,nn2,mm) = edges(nn1,nn2,mm);
            end
        end
        Attribu(nn1,size(Z_spiketrain_real_avesimul,1)+1,mm) = Z_spiketrain_Wilcoxon_test2(nn1,mm);
    end
end
D = [];% D �����˳ɶ���Ԫ֮�����Ե��ܲ��졣
for mm = 1:size(Z_spiketrain_real_avesimul,4)%����ɶ���Ԫ֮���attributions��࣬�ҵ������Զ��k����Ԫ
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            D(nn1,nn2,mm) = sum(abs(Attribu(nn1,:,mm)-Attribu(nn2,:,mm)));
        end
    end
end
Initial_assemble = [];d1 = 0;
for mm = 1:size(Z_spiketrain_real_avesimul,4)%��ƽ���������������Ԫ��Ϊ��ʼ�ķ���
    d1 = 0;
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        for nn2 = 1:size(Z_spiketrain_real_avesimul,1)
            for nn3 = 1:size(Z_spiketrain_real_avesimul,1)
                if (nn1~=nn2)&&(nn2~=nn3)&&(nn1~=nn3)
                d2 = [D(nn1,nn2,mm) D(nn1,nn3,mm) D(nn2,nn3,mm)];
%                 d2
%                 mean(d2)
                d1 = max(d1,mean(d2));
                if d1 == mean(d2)
                    1;
                    Initial_assemble(:,mm) = [nn1 nn2 nn3];
                end
                end
            end
        end
    end
end
neural_assemble = [];d1 = 0;
for mm = 1:size(Z_spiketrain_real_avesimul,4)
    neural_assemble(:,1,mm) = Initial_assemble(:,mm);
    for nn1 = 1:size(Z_spiketrain_real_avesimul,1)
        if isempty(find(nn1 == neural_assemble(:,:,mm),1))
            d1 = zeros(size(neural_assemble,1),1);nn = [];
            for nn2 = 1:size(neural_assemble,1)%�Ƚ�nn1��Ԫ��nn2���е�ÿ����Ԫ�Ĳ��֮��
                bb = neural_assemble(nn2,:,mm);
                bb = bb(bb>0);
                for nn3 = 1:length(bb)
                    d1(nn2,1) = d1(nn2,1) + D(nn1,nn3,mm);
                end
                d1(nn2,1) = d1(nn2,1)/length(bb);
            end
            nn = find(d1 == min(d1),1);
            bb3 = neural_assemble(nn,:,mm);
            bb3 = bb3(bb3>0);
            neural_assemble(nn,length(bb3)+1,mm) = nn1;
        end
    end
end
save('neural_assemble1','neural_assemble');

shape = ['o','+','d'];%% ���ڸ��������������ͬ������Ĳ�ͬ��ԪȺ�廮�֡�
for m = 1:size(neural_assemble,3)
    subplot(2,2,m);
    n_neuron = 0;
 for x = 1:20
    for y = 1:10
        n_neuron = n_neuron + 1;
        [n_assembel,~] = find(n_neuron == neural_assemble(:,:,m));
        a = x;b = y;
        plot(a,b,shape(n_assembel),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.4);hold on;
        %color1 = n_assembel*[0.25,0.25,0.25];
        
    end
 end
 xlim([0 21]);ylim([0 11]);
end

n_neuron = [];
for mm = 1:size(neural_assemble,3)
    for n_assemble = 1:3
       n_neuron0 = neural_assemble(n_assemble,:,mm);
       n_neuron0 = n_neuron0(n_neuron0>0);
       n_neuron(mm,n_assemble) = length(n_neuron0);
    end
end
figure;h = bar(n_neuron);
for mm = 1:size(neural_assemble,3)
    h(mm).FaceColor = [mm*0.2 mm*0.2 mm*0.2];
end



%% ����������ԪȺ���������ƶϵĹ��ס�
load('NeuralrespPCA1');
size(NeuralrespPCA)
NeuralassemblContri = cell(size(NeuralrespPCA,4),1);
for nn = 1:size(NeuralrespPCA,4)
       Neuralresp0 = [];
       for n1 = 1:size(NeuralrespPCA,1)
           Neuralresp0(n1,:) = NeuralrespPCA(n1,1,:,nn);
       end
       %a = rand(20,20);% a��ԭʼ����
       a = Neuralresp0';
       b = cov(a);% co-variance matrix
       b1 = cov(b);% b�����ɷַ����Ķ���b1��b��Э�������
       [coeff, score, latent, tsquared, explained, mu] = pca(b);% b�����ɷַ����Ķ���
       % coeff returns the principal component coefficients for the N by P data matrix X. Rows of X correspond to observations 
       % and columns to variables. Each column of COEFF contains coefficients
       % for one principal component. 
       % LATENT returns the principal component variances, i.e., the eigenvalues of the covariance matrix of X.
       % ������֤��coeff ����Э������������������ɵľ�����ʾ����ԭ���ݵ����ɷֵ����Ա仯��
       for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90
               [n,c]
               N_PCA = n;%N_PCA��n�����ɷֵĸ�����
               break
           end 
       end % ǰn�����ɷֽ�����90%�ķ��
       b1 = cov(b);% b�����ɷַ����Ķ���b1��b��Э�������
   
       [V,D] = eig(b1);
   
       eigvalue = diag(D);
   
       [~,idx] = sort(eigvalue,'descend');
   
       V1 = V(:,idx);
   
       eigvalue1 = eigvalue(idx);% V1��b1������ֵ��
   
       D1 = diag(eigvalue1);
   
       V*D*inv(V); %V,D�Ǿ���b1������ֵ�ֽ�,V*D*inv(V) = b1;
       V1*D1*inv(V1); %V1,D1�Ǿ���b1������ֵ�ֽ����������,V1*D1*inv(V1) = b1;
       % ���Լ���b�е�ÿһ�ж������ɷֵĹ��ס�
       radio0 = zeros(size(b,2),N_PCA);
   
       for n = 1:size(b,2) % n�Ǹ�����Ԫ�����
        for m = 1:N_PCA % m�Ǹ������ɷֵ����
           clear t;clear lam;clear sig;
           t = coeff(n,m)^2;%ѡ���n��ԭʼ���ݵ���m�����ɷֵ�����ϵ����
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t/sig;
        end
       
       end
       NeuralassemblContri{nn,1} = radio0;%�����˶���ÿ�������ÿ����Ԫ���ڸ������ɷֵĹ��׳̶ȡ�
end
save('NeuralassemblContri','NeuralassemblContri');
%% ���ڸ����̼���������ԪȺ��Ĺ��ס�
Neural_assemb_contri = zeros(size(neural_assemble,3),size(neural_assemble,1));
for m = 1:size(neural_assemble,3)
    %Neural_assemb_contri = zeros(m,size(neural_assemble,1));
    for n_assemble = 1:size(neural_assemble,1)
        neuron = [];neural_assemb_contri = [];
        neuron = neural_assemble(n_assemble,:,m);
        neuron = neuron(:);
        neuron = neuron(neuron>0);
        neural_assemb_contri = NeuralassemblContri{m,1}(neuron,:);
        Neural_assemb_contri(m,n_assemble) = sum(neural_assemb_contri(:));
    end
    total = sum(Neural_assemb_contri(m,:));
    Neural_assemb_contri(m,:) = Neural_assemb_contri(m,:)./total;
end
figure;hold on;
h = bar(Neural_assemb_contri);
x = 1:size(neural_assemble,3);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:size(neural_assemble,3)
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
    xlim([0.5 size(neural_assemble,3)+0.5]);
end
%% ������Ԫ����������ڸ����̼��Ĺ���
Neural_contri = [];
for n = 1:size(NeuralassemblContri{1,1},1)% n����Ԫ���
    neural_contri = [];
    for mm = 1:size(NeuralassemblContri,1)
       neural_contri = sum(NeuralassemblContri{mm,1}(n,:));
       Neural_contri(n,mm) = neural_contri;
    end
end
%% ���ڸ����̼�����ÿ����Ԫ�Ĺ��״�С����
ID = [];
for mm = 1:size(NeuralassemblContri,1)
    
    neural_contri0 = Neural_contri(:,mm);
    [~,ID(:,mm)] = sort(neural_contri0,'descend');
end
neural_contri1 = [];
for mm = 1:size(NeuralassemblContri,1)
    for n = 1:size(NeuralassemblContri{1,1},1) % n����Ԫ���
        k = find(n == ID(:,mm),1);
        neural_contri1(mm,n) = k; %��¼��ÿ���̼�ÿ����Ԫ���׶ȵ�����
    end
    clear neural_contri2;
    neural_contri2 = reshape(neural_contri1(mm,:),10,20);
    bottom1 = min(neural_contri2(:));top1 = max(neural_contri2(:));
    color1 = [];
    for l1 = 1:size(neural_contri2,1)
        for l2 = 1:size(neural_contri2,2)
               color1(l1,l2) = (neural_contri2(l1,l2) - bottom1)/(top1 - bottom1);
        end
    end
    figure;b = bar3(neural_contri2);
    for ll = 1:size(b,2)
        b(1,ll).FaceColor = 'white';
    end
end

%% ����ÿ���̼�����Ԫ��Ⱥ���׶���ʱ��ı仯
NeuralassemblContri0 = cell(size(Z_cout1,4),size(Z_cout1,2));
for tt = 1:size(Z_cout1,2)
    Neuralresp = Z_cout1(:,tt,:,:);
    % NeuralassemblContri0 = cell(size(Neuralresp,4),1);
    for nn = 1:size(Neuralresp,4)
        Neuralresp0 = [];
        for n1 = 1:size(Neuralresp,1)
           Neuralresp0(n1,:) = Neuralresp(n1,1,:,nn);
        end
        a = Neuralresp0';
        b = cov(a);% co-variance matrix
        b1 = cov(b);% b�����ɷַ����Ķ���b1��b��Э�������
        [coeff, score, latent, tsquared, explained, mu] = pca(b);% b�����ɷַ����Ķ���
        for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90
               [n,c]
               N_PCA = n;%N_PCA��n�����ɷֵĸ�����
               break
           end  
        end % ǰn�����ɷֽ�����90%�ķ��
        b1 = cov(b);% b�����ɷַ����Ķ���b1��b��Э�������
        [V,D] = eig(b1);
        eigvalue = diag(D);
        [~,idx] = sort(eigvalue,'descend');
        V1 = V(:,idx);
        eigvalue1 = eigvalue(idx);% V1��b1������ֵ��
        D1 = diag(eigvalue1);
        radio0 = zeros(size(b,2),N_PCA);
        for n = 1:size(b,2) % n�Ǹ�����Ԫ�����
         for m = 1:N_PCA % m�Ǹ������ɷֵ����
           clear t;clear lam;clear sig;
           t1 = coeff(n,m)^2;%ѡ���n��ԭʼ���ݵ���m�����ɷֵ�����ϵ����
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t1/sig;
         end
        end
     NeuralassemblContri0{nn,tt} = radio0;%�����˶���ÿ�������ÿ����Ԫ���ڸ������ɷֵĹ��׳̶ȡ�
    end
end

Neural_assemble_temporal_contri = cell(size(Z_cout1,4),1);
for nn = 1:size(Z_cout1,4)% ����ÿ���̼���̽����ԪȺ�幱�׶���ʱ��ı仯��
    % neural_assemble_temporal_contri2 = [];
    clear neural_assemble_temporal_contri2;
    for ll = 1:size(neural_assemble,1)
            neuron = neural_assemble(ll,:,nn);
            neuron = neuron(neuron>0);
            
            for t = 1:size(Z_cout1,2)
                clear neural_assemble_temporal_contri0;clear neural_assemble_temporal_contri1;
                neural_assemble_temporal_contri0 = NeuralassemblContri0{nn,t};
                neural_assemble_temporal_contri1 = neural_assemble_temporal_contri0(neuron(:),:);
                neural_assemble_temporal_contri2(ll,t) = sum(sum(neural_assemble_temporal_contri1,2));
            end
    end
    
    Neural_assemble_temporal_contri{nn,1} = neural_assemble_temporal_contri2;
    t1 = 1:1:size(Z_cout1,2);
    figure;
    for k1 = 1:size(neural_assemble_temporal_contri2,1)
        plot(t1,neural_assemble_temporal_contri2(k1,:),'color',[0.25 0.25 0.25]*k1);hold on;
    end
    legend('assemble 1','assemble 2','assemble 3');
end


    
    


   
   
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ������Ԫ�̼�ǰ����ڴ̼�����Ӱ�졣

Z_rate_real = zeros(size(Z_cout2,1),T,L,size(stimulus,2)*2);
for l_style = 1:size(stimulus,2)*2
 for l = 1:L
  for t = 1:T
    for t1=1:T
        for n=1:size(Z_cout1,1)
            Z_rate_real(n,t,l,l_style) = Z_rate_real(n,t,l,l_style)+Z_cout1(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end
Z_rate_pe = zeros(size(Z_cout2,1),T,L,size(stimulus,2)*2);
for l_style = 1:size(stimulus,2)*2
 for l = 1:L
  for t=1:T
    for t1=1:T
        for n=1:size(Z_cout2,1)
            Z_rate_pe(n,t,l,l_style) = Z_rate_pe(n,t,l,l_style)+Z_cout2(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end
% save('Z_rate_real','Z_rate_real');save('Z_rate_pe','Z_rate_pe');
% load('Z_rate_real');load('Z_rate_pe')
%% 

Z_rate_pe_popu = sum(Z_rate_pe,1);
Z_rate_real_popu =  sum(Z_rate_real,1);
clear Z_real_mean;clear Z_real_std;
for l_style = 1:size(stimulus,2)*2
  for t = 1:T
   Z_real_mean(1,t,l_style) = mean(Z_rate_real_popu(1,t,:,l_style));
   Z_real_std(1,t,l_style) = std(Z_rate_real_popu(1,t,:,l_style));  
  end
end
clear Z_pe_mean;clear Z_pe_std;
for l_style = 1:size(stimulus,2)*2
 for t= 1:T
  Z_pe_mean(1,t,l_style) = mean(Z_rate_pe_popu(1,t,:,l_style));
  Z_pe_std(1,t,l_style) = std(Z_rate_pe_popu(1,t,:,l_style));
 end
end

x = 1:(size(stimulus,2)*2*2*T);y1 = [];
for n1 = 1:size(Z_pe_std,3)
    y1 = [y1,Z_pe_std(:,:,n1),Z_real_std(:,:,n1)];
end

figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('SD');
ylim([0,1.2*max(y1)]);hold on;xlabel('timestep');
for t =1:length(x)
    if mod(t,T) == 0
        plot([t,t],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    end
end
% 
% plot([40,40],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
% plot([60,60],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;


N = size(test_data{1,l}.Zleftt,1);
Zleft_ISI_real = zeros(N,T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
   for n=1:N
    t1 = 0;t2 = 0;j = 0;
    while t1<T
      t1 = min(t1 + 1,T);
      if (Zleft_cout1(n,t1,l,l_style)==1)
          t2 = min(t1+1,T);
          while (t2<T)&&(Zleft_cout1(n,t2,l,l_style)==0)
              t2 = min(t2 + 1,T);
          end
          if (Zleft_cout1(n,t2,l,l_style)==1)&&(Zleft_cout1(n,t1,l,l_style)==1)
              [n,l,t1,t2];
              j=j+1;
              Zleft_ISI_real(n,j,l,l_style) = abs(t2-t1);
          end
      end
      
    end
    end
 end

end

Zleft_ISI_pe = zeros(N,T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
   for n=1:N
    t1 = 0;t2 = 0;j = 0;
    while t1<T
      t1 = min(t1 + 1,T);
      if (Zleft_cout2(n,t1,l,l_style)==1)
          t2 = min(t1+1,T);
          while (t2<T)&&(Zleft_cout2(n,t2,l,l_style)==0)
              t2 = min(t2 + 1,T);
          end
          
          if (Zleft_cout2(n,t2,l,l_style)==1)&&(Zleft_cout2(n,t1,l,l_style)==1)
              [n,l,t1,t2];
              j=j+1;
              Zleft_ISI_pe(n,j,l,l_style) = abs(t2-t1);
          end
      end
    end
    end
 end

end


for l_style = 1:size(stimulus,2)
    Zleft_ISI_real0 = Zleft_ISI_real(:,:,:,l_style);
    Zleft_ISI_real1 = Zleft_ISI_real0(Zleft_ISI_real0~=0);
    CV_real(l_style) = std(Zleft_ISI_real1)/mean(Zleft_ISI_real1);
    Zleft_ISI_pe0 = Zleft_ISI_pe(:,:,:,l_style);
    Zleft_ISI_pe1 = Zleft_ISI_real0(Zleft_ISI_pe0~=0);
    CV_pe(l_style) = std(Zleft_ISI_pe1)/mean(Zleft_ISI_pe1);
end
Zleft_ISI_real = Zleft_ISI_real(Zleft_ISI_real~=0);

name01 = [];name02 = [];
figure;
for l_style = 1:size(stimulus,2)
plot([1,2],[CV_pe(1,l_style),CV_real(1,l_style)],'-o');hold on
name01 = ['situation',num2str(l_style)];
name02 = [name02;name01];
end
xlim([0,3]);ylabel('CV of ISI');
set(gca,'XTick',[0.5,1,2,2.5],'xticklabel',{'','psedo','real',''});
legend(name02);hold on
%legend('Sti.1','Sti.2');
%legend('Sti.3','Sti.4');


%%

T1 = 2*T;
j = 1;clear Zleft_cout1;clear Zright_cout1;clear Z_cout1;% cout1 for real;
 for l_style = 1:size(stimulus,2)
    
    for l = 1:L
    
    Zleft = zeros(size(test_data{1,l}.Zleftt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      [t,t-(j-1)*2*T-T-T1];
      for n = 1:size(test_data{1,l}.Zleftt,1)
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*2*T-T-T1) = 1;
          end
      end
    end
    Zleft_cout1(:,:,l,l_style) = Zleft;
    
    Zright = zeros(size(test_data{1,l}.Zrightt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      for n = 1:size(test_data{1,l}.Zrightt,1)
              if test_data{1,l}.Zrightt(n,t) == 1
                Zright(n,t-(j-1)*2*T-T-T1) = 1;
              end  
      end
    end
    Zright_cout1(:,:,l,l_style) = Zright;
    
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T-T1) = 1;
              end
      end
    end
    Z_cout1(:,:,l,l_style) = Z;
    
    end
    j = 1+j;
 end
j = 1;clear Zleft_cout2;clear Zright_cout2;clear Z_cout2;% cout2 for pre;
for l_style = 1:size(stimulus,2)
for l = 1:L
    
    Zleft = zeros(size(test_data{1,l}.Zleftt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      
      for n = 1:size(test_data{1,l}.Zleftt,1)
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*2*T-T1) = 1;
          end
      end
    end
    Zleft_cout2(:,:,l,l_style) = Zleft;
    
    Zright = zeros(size(test_data{1,l}.Zrightt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.Zrightt,1)
              if test_data{1,l}.Zrightt(n,t) == 1
                Zright(n,t-(j-1)*2*T-T1) = 1;
              end  
      end
    end
    Zright_cout2(:,:,l,l_style) = Zright;

    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T1) = 1;
              end
      end
    end
    Z_cout2(:,:,l,l_style) = Z;
end
j = 1+j;
end
Zleft_rate_real = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
Zright_rate_real = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
for l = 1:L
for t=1:T
    for t1=1:T
        for n=1:size(Zleft_cout1,1)
            Zleft_rate_real(n,t,l,l_style) = Zleft_rate_real(n,t,l,l_style)+Zleft_cout1(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_real(n,t,l,l_style) = Zright_rate_real(n,t,l,l_style)+Zright_cout1(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
end
end
end
Zleft_rate_pe = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
Zright_rate_pe = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t= 1:T
    for t1=1:T
        for n = 1:size(Zleft_cout2,1)
            Zleft_rate_pe(n,t,l,l_style) = Zleft_rate_pe(n,t,l,l_style)+Zleft_cout2(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_pe(n,t,l,l_style) = Zright_rate_pe(n,t,l,l_style)+Zright_cout2(n,t1,l,l_style)*normpdf(t1-t,0,20);  
        end
    end
  end
 end
end
clear crosscorr0;clear crosscorr_pe��
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t= 1:T
      for n = 1:size(Zleft_cout2,1)
          for n1 = 1:size(Zleft_cout2,1)
          crosscorr0(n,n1,l_style,t,l) = Zleft_rate_pe(n,t,l,l_style)*Zleft_rate_pe(n1,t,l,l_style);
          end
      end
  end
 end
end
crosscorr_pe = mean(mean(crosscorr0,5),4);
clear Eigenvector_pe;clear Eigenvalue_pe;clear a1_pe;clear value_pe;
for l_style = 1:size(stimulus,2)
    [Eigenvector_pe(:,:,l_style),Eigenvalue_pe(:,:,l_style)] = eig(crosscorr_pe(:,:,l_style));
    %a1_pe(:,l_style) = diag(Eigenvalue_pe(:,:,l_style));
    %a1_pe(:,l_style) = a1_pe(:,l_style)./sum(a1_pe(:,l_style));
    a1_pe(:,l_style) = sort(diag(Eigenvalue_pe(:,:,l_style))./sum(diag(Eigenvalue_pe(:,:,l_style))),'descend');
    value_pe(:,l_style) = sort(diag(Eigenvalue_pe(:,:,l_style)),'descend');
    %a1_pe(:,l_style) = sort(diag(Eigenvalue_pe(:,:,l_style)./sum(diag(Eigenvalue_pe(:,:,l_style)))),'descend');
end

clear crosscorr0;clear crosscorr_real��
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t= 1:T
      for n = 1:size(Zleft_cout2,1)
          for n1 = 1:size(Zleft_cout2,1)
          crosscorr0(n,n1,l_style,t,l) = Zleft_rate_real(n,t,l,l_style)*Zleft_rate_real(n1,t,l,l_style);
          end
      end
  end
 end
end
crosscorr_real = mean(mean(crosscorr0,5),4);
clear Eigenvector_real;clear Eigenvalue_real;clear a1_real;clear value_real;
for l_style = 1:size(stimulus,2)
    [Eigenvector_real(:,:,l_style),Eigenvalue_real(:,:,l_style)] = eig(crosscorr_real(:,:,l_style));
    %a1_real(:,l_style) = diag(Eigenvalue_real(:,:,l_style));
    %a1_real(:,l_style) = a1_real(:,l_style)./sum(a1_real(:,l_style));
    a1_real(:,l_style) = sort(diag(Eigenvalue_real(:,:,l_style))./sum(diag(Eigenvalue_real(:,:,l_style))),'descend');
    value_real(:,l_style) = sort(diag(Eigenvalue_real(:,:,l_style)),'descend');
    %a1_real(:,l_style) = sort(diag(Eigenvalue_real(:,:,l_style)./sum(diag(Eigenvalue_real(:,:,l_style)))),'descend');
end
for l_style = 1:size(stimulus,2)
    d = 0;per1 = 0;per2 = 0;
    for l = 1:size(a1_real(:,l_style),1)
        per1 = per1 + a1_pe(l,l_style);
        per2 = per2 + a1_real(l,l_style);
        if (min(per1,per2)>=0.75)
            d = l
            break
        end
    end
    dim1 = (sum(value_pe(1:d,l_style)))^2/sum(value_pe(1:d,l_style).^2)
    dim2 = (sum(value_real(1:d,l_style)))^2/sum(value_real(1:d,l_style).^2)
    x = 1:d;
    figure;
    plot(x,a1_pe(1:d,l_style),'o');hold on;
    plot(x,a1_real(1:d,l_style),'*');hold on;
    legend('pre-stimulus','post-stimulus');
    xlabel('Principal component #');
    ylabel('Percent variance');
    x = [0.5,2.5];y = [dim1,dim2];
    figure;
    plot(x,y,'o-');xlim([0 3]);set(gca,'xtick',[]);
end
%     ylim([0,max(max(a1_pe(1:d,l_style)),max(a1_real(1:d,l_style)))]);
%     Mean1 = mean(a1_pe(1:d,l_style));Mean2 = mean(a1_real(1:d,l_style));
%     err1 = std(a1_pe(1:d,l_style));err2 = std(a1_real(1:d,l_style));
%     d = 0.05;
%     x1 = 0.5;x2 = 1.5;
%     x3 = 2.5;x4 = 3.5;
%     y11 = Mean1 - err1;y12 = Mean1 + err1;
%     y21 = Mean2 - err2;y22 = Mean2 + err2;
%     x = x1:d:x2;y = ones(size(x))*Mean1;
%     figure;
%     fill([x1 x1 x2 x2],[y11 y12 y12 y11],[0.8,0.8,0.8]);hold on;
%     plot(x,y,'.k');hold on;
%     x = x3:d:x4;y = ones(size(x))*Mean2;
%     fill([x3 x3 x4 x4],[y21 y22 y22 y21],[0.8,0.8,0.8]);hold on;
%     plot(x,y,'.k');hold on;

%%

T1 = 2*T;
j = 1;clear Zleft_cout1;clear Zright_cout1;clear Z_cout1;
for l_style = 1:size(stimulus,2)
    
    for l = 1:L
    
    Zleft = zeros(size(test_data{1,l}.Zleftt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      [t,t-(j-1)*2*T-T-T1];
      for n = 1:size(test_data{1,l}.Zleftt,1)
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*2*T-T-T1) = 1;
          end
      end
    end
    Zleft_cout1(:,:,l,l_style) = Zleft;
    
    Zright = zeros(size(test_data{1,l}.Zrightt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      for n = 1:size(test_data{1,l}.Zrightt,1)
              if test_data{1,l}.Zrightt(n,t) == 1
                Zright(n,t-(j-1)*2*T-T-T1) = 1;
              end  
      end
    end
    Zright_cout1(:,:,l,l_style) = Zright;
    
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T-T1) = 1;
              end
      end
    end
    Z_cout1(:,:,l,l_style) = Z;
    
    end
    j = 1+j;
end
j = 1;clear Zleft_cout2;clear Zright_cout2;clear Z_cout2;
for l_style = 1:size(stimulus,2)
 for l = 1:L
    Zleft = zeros(size(test_data{1,l}.Zleftt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      
      for n = 1:size(test_data{1,l}.Zleftt,1)
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*2*T-T1) = 1;
          end
      end
    end
    Zleft_cout2(:,:,l,l_style) = Zleft;
    Zright = zeros(size(test_data{1,l}.Zrightt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.Zrightt,1)
              if test_data{1,l}.Zrightt(n,t) == 1
                Zright(n,t-(j-1)*2*T-T1) = 1;
              end  
      end
    end
    Zright_cout2(:,:,l,l_style) = Zright;
    Z = zeros(size(test_data{1,l}.Zt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*2*T-T1) = 1;
              end
      end
    end
    Z_cout2(:,:,l,l_style) = Z;
 end
j = 1+j;
end

Zleft_rate_real = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
Zright_rate_real = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
for l = 1:L
for t=1:T
    for t1=1:T
        for n=1:size(Zleft_cout1,1)
            Zleft_rate_real(n,t,l,l_style) = Zleft_rate_real(n,t,l,l_style)+Zleft_cout1(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_real(n,t,l,l_style) = Zright_rate_real(n,t,l,l_style)+Zright_cout1(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
end
end
end
Zleft_rate_pe = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
Zright_rate_pe = zeros(size(Zleft_cout2,1),T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t=1:T
    for t1=1:T
        for n=1:size(Zleft_cout2,1)
            Zleft_rate_pe(n,t,l,l_style) = Zleft_rate_pe(n,t,l,l_style)+Zleft_cout2(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_pe(n,t,l,l_style) = Zright_rate_pe(n,t,l,l_style)+Zright_cout2(n,t1,l,l_style)*normpdf(t1-t,0,20);  
        end
    end
  end
 end
end

clear C2;C2 = zeros(size(test_data{1,l}.Zleftt,1),L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for l = 1:L
      for n = 1:size(test_data{1,l}.Zleftt,1)
          clear spike_train;
          spike_train = Zleft_cout1(n,:,l,l_style);
          spike_train;
          [C1, H] = calc_lz_complexity(spike_train, 'exhaustive', 1);
          C2(n,l,l_style) = C1;
      end
    end
end
C_real1 = mean(C2,2);

clear C3;C3 = zeros(size(test_data{1,l}.Zleftt,1),L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for l = 1:L
      for n = 1:size(test_data{1,l}.Zleftt,1)
          clear spike_train;
          spike_train = Zleft_cout2(n,:,l,l_style);
          [C1, H] = calc_lz_complexity(spike_train, 'exhaustive', 1);
          C3(n,l,l_style) = C1;
      end
    end
end
C_pre1 = mean(C3,2);
clear Complexity;
for l_style = 1:size(stimulus,2)
    Complexity(:,l_style,1) = C_pre1(:,1,l_style);
    Complexity(:,l_style,2) = C_real1(:,1,l_style);
end
ytop = 1.05*max(Complexity(:));
ybottom = 0.8*min(Complexity(:));
figure;aa = [];
for l_style = 1:size(stimulus,2)
    x1 = [1 2];
    y1 = Complexity(:,l_style,1)';
    y2 = Complexity(:,l_style,2)';
    mean0 = [mean(y1),mean(y2)];std0 = [std(y1),std(y2)];
    errorbar(x1,mean0,std0);hold on;
    %plot(x1,y1,'-o');hold on;
    ylim([ybottom ytop]);xlim([0.5 2.5]);
    %xlabel([0.5 2.5]);
    aa = [aa;'situation',num2str(l_style)];
end
legend(aa);
set(gca,'XTick',[0.5,1,2,2.5],'xticklabel',{'','psedo','real',''});
title('Complexity of neural responding sequences');
%%

Zleft_real = cell(1,size(stimulus,2));
Zleft_pe = cell(1,size(stimulus,2));

for l_style = 1:size(stimulus,2)
    Zleft_real0 = zeros(T,1);Zleft_pe0 = zeros(T,1);
    for l = 1:L
       for t = 1:T
           Zleft_real0(t,l) = Zleft_rate_real_popu(1,t,l,l_style);
           Zleft_pe0(t,l) = Zleft_rate_pe_popu(1,t,l,l_style);
       end    
    end
    Zleft_real{1,l_style} = Zleft_real0;
    Zleft_pe{1,l_style} = Zleft_pe0;
end
Var_sti = zeros(T,size(stimulus,2));
p_XY = zeros(T,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T
        clear Zleftreal;clear Zleftpe;clear Cov_XY;
        Zleftreal = Zleft_real{1,l_style}(t,:);
        Zleftpe = Zleft_pe{1,l_style}(t,:);
        Zleftreal = Zleftreal(:);
        Zleftpe = Zleftpe(:);
        E_XY = mean(Zleftreal.*Zleftpe);
        E_Y2 = mean(Zleftpe.^2);
        E_Y = mean(Zleftpe);
        E_X = mean(Zleftreal);
        Cov_Y_X_Y = E_XY - E_Y2 + E_Y^2 - E_X*E_Y;
        Cov_XY = cov(Zleftreal,Zleftpe);
        Var_sti(t,l_style) = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);
        Var_Y = var(Zleftpe);
        p_XY(t,l_style) = Cov_Y_X_Y/sqrt(Var_sti(t,l_style)*Var_Y);
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,Var_sti(:,l_style));hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
legend(aa);ylabel('stimulus-induced excitatory variability');
xlabel('timestep');
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,p_XY(:,l_style),'color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;

    
    aa = [aa;'Sti.',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('timestep');title('pre- and post-stimulus excitatory neural responding correlation');
hold on;
for l_style = 1:size(stimulus,2)
    for x = 1:T
        if abs(p_XY(x,l_style))>=0.3
           plot(x,p_XY(x,l_style),'*','color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
        end
    end
end
%%

j = 1;clear I_cout1;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    I = zeros(size(test_data{1,l}.lt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      [t,t-(j-1)*2*T-T-T1];
      for n = 1:size(test_data{1,l}.lt,1)
          if test_data{1,l}.lt(n,t) == 1
             I(n,t-(j-1)*2*T-T-T1) = 1;
          end
      end
    end
    I_cout1(:,:,l,l_style) = I;
    end
    j = 1+j;
end
j = 1;clear I_cout2;
for l_style = 1:size(stimulus,2)
for l = 1:L
    
    I = zeros(size(test_data{1,l}.lt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      for n = 1:size(test_data{1,l}.lt,1)
          if test_data{1,l}.lt(n,t) == 1
             I(n,t-(j-1)*2*T-T1) = 1;
          end
      end
    end
    I_cout2(:,:,l,l_style) = I; 
end
j = 1+j;
end
I_rate_real = zeros(size(I_cout2,1),T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
for l = 1:L
for t=1:T
    for t1=1:T
        for n=1:size(I_cout1,1)
            I_rate_real(n,t,l,l_style) = I_rate_real(n,t,l,l_style)+I_cout1(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
end
end
end
I_rate_pe = zeros(size(I_cout2,1),T,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t=1:T
    for t1=1:T
        for n=1:size(I_cout1,1)
            I_rate_pe(n,t,l,l_style) = I_rate_pe(n,t,l,l_style)+I_cout2(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end  
  end
 end
end
I_rate_pe_popu = sum(I_rate_pe,1);
I_rate_real_popu = sum(I_rate_real,1);

I_real = cell(1,size(stimulus,2));
I_pe = cell(1,size(stimulus,2));

for l_style = 1:size(stimulus,2)
    
    I_real0 = zeros(T,1);I_pe0 = zeros(T,1);
    for l = 1:L
        for t=1:T
           I_real0(t,l) = I_rate_real_popu(1,t,l,l_style);%(Zleft_rate_real_popu(1,t,l,l_style)-Zleft_mean3(1,l,l_style))/Zleft_std3(1,l,l_style);
           I_pe0(t,l) = I_rate_pe_popu(1,t,l,l_style);
        end 
    end
    I_real{1,l_style} = I_real0;
    I_pe{1,l_style} = I_pe0;
end
clear I_std;
for l_style = 1:size(stimulus,2)
    for t = 1:T
        I_std(t,l_style) = std(I_real{1,l_style}(t,:));
    end
    I_std(:,l_style) = (I_std(:,l_style)-std(I_pe{1,l_style}(T,:)))/std(I_pe{1,l_style}(T,:));
end

std_buttom = 0.95*min([I_std(:);I_std(:)]);
std_top = 1.1*max([I_std(:);I_std(:)]);

figure;aa = [];
for l_style = 1:size(stimulus,2)
    x1 = 1:T;x2 = I_std(:,l_style)';
    plot(x1,x2);hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
ylabel('Inhibitory VVT with pseudo-activites');xlabel('timestep');
title('Normalized inhibitory VVT to Stimuli');ylim([std_buttom,std_top]);
legend(aa);



Var_sti_inhi = zeros(T,size(stimulus,2));
p_XY_inhi = zeros(T,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T
        clear Ireal;clear Ipe;clear Cov_XY;
        Ireal = I_real{1,l_style}(t,:);
        Ipe = I_pe{1,l_style}(t,:);
        
        E_XY = mean(Ireal.*Ipe);
        E_Y2 = mean(Ipe.^2);
        E_Y = mean(Ipe);
        E_X = mean(Ireal);
        Cov_Y_X_Y = E_XY - E_Y2 + E_Y^2 - E_X*E_Y;
        Cov_XY = cov(Ireal,Ipe);
        Var_sti_inhi(t,l_style) = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);
        Var_Y = var(Ipe);
        p_XY_inhi(t,l_style) = Cov_Y_X_Y/sqrt(Var_sti_inhi(t,l_style)*Var_Y);  
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,Var_sti_inhi(:,l_style));hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
ylabel('stimulus-induced inhibitory neural variability');
xlabel('timestep');
legend(aa);

figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,p_XY_inhi(:,l_style),'color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);
    hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
ylabel('inhibitory Pearson correlation coefficient');
xlabel('timestep');
legend(aa);
hold on;
for l_style = 1:size(stimulus,2)
    for x = 1:T
        if abs(p_XY_inhi(x,l_style))>=0.3
           plot(x,p_XY_inhi(x,l_style),'*','color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
        end
    end
end
%% correlation between ex and in
for l_style = 1:size(stimulus,2)
    for t = 1:T
        clear Ireal;clear Ipe;clear Zleftreal;clear Zleftpe;
        Ireal = I_real{1,l_style}(t,:);
        Ipe = I_pe{1,l_style}(t,:);
        Zleftreal = Zleft_real{1,l_style}(t,:);
        Zleftpe = Zleft_pe{1,l_style}(t,:);
        EX2_Y1_X1 = mean(Ipe.*(Zleftreal-Zleftpe));
        EX2 = mean(Ipe);
        EY1_X1 = mean(Zleftreal-Zleftpe);
        COV0 = EX2_Y1_X1-EX2*EY1_X1;
        p0(t,l_style) = COV0/sqrt(var(Ipe)*Var_sti(t,l_style));
    end
end

figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,p0(:,l_style),'color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('timestep');title('stimulus-induced excitatory and pre-stimulus inhibitory correlation');
hold on;
for l_style = 1:size(stimulus,2)
    for x = 1:T
        if abs(p0(x,l_style))>=0.3
           plot(x,p0(x,l_style),'*','color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
        end
    end
end


for l_style = 1:size(stimulus,2)
    for t = 1:T
        clear Ireal;clear Ipe;clear Zleftreal;clear Zleftpe;
        Ireal = I_real{1,l_style}(t,:);
        Ipe = I_pe{1,l_style}(t,:);
        Zleftreal = Zleft_real{1,l_style}(t,:);
        Zleftpe = Zleft_pe{1,l_style}(t,:);
        EX2_Y1_X1 = mean(Zleftpe.*(Ireal-Ipe));
        EX2 = mean(Zleftpe);
        EY1_X1 = mean(Ireal-Ipe);
        COV0 = EX2_Y1_X1-EX2*EY1_X1;
        p0(t,l_style) = COV0/sqrt(var(Zleftpe)*Var_sti_inhi(t,l_style));
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,p0(:,l_style),'color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
legend(aa);
xlabel('timestep');ylabel('Pearson correlation coefficient');
title('stimulus-induced inhibitory and pre-stimulus excitatory correlation');
hold on;
for l_style = 1:size(stimulus,2)
    for x = 1:T
        if abs(p0(x,l_style))>=0.3
           plot(x,p0(x,l_style),'*','color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
        end
    end
end
for l_style = 1:size(stimulus,2)
    for t = 1:T
        clear Ireal;clear Ipe;clear Zleftreal;clear Zleftpe;
        Ireal = I_real{1,l_style}(t,:);
        Ipe = I_pe{1,l_style}(t,:);
        Zleftreal = Zleft_real{1,l_style}(t,:);
        Zleftpe = Zleft_pe{1,l_style}(t,:);
        EY2_X2_Y1_X1 = mean((Zleftreal-Zleftpe).*(Ireal-Ipe));
        EY2_X2 = mean(Zleftreal-Zleftpe);
        EY1_X1 = mean(Ireal-Ipe);
        COV0 = EY2_X2_Y1_X1-EY2_X2*EY1_X1;
        p0(t,l_style) = COV0/sqrt(Var_sti(t,l_style)*Var_sti_inhi(t,l_style));
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T;
    plot(X,p0(:,l_style),'color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
    aa = [aa;'Sti.',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
title('stimulus-induced excitatory and stimulus-induced inhibitory correlation');
xlabel('timestep');
hold on;
for l_style = 1:size(stimulus,2)
    for x = 1:T
        if abs(p0(x,l_style))>=0.3
           plot(x,p0(x,l_style),'*','color',[0,1-(l_style-1)/size(stimulus,2),(l_style-1)/size(stimulus,2)]);hold on;
        end
    end
end

%%

T1 = 2*T;
j = 1;clear Zleft_cout1;clear Zright_cout1;clear Z_cout1;% cout1 for real;
for l_style = 1:size(stimulus,2)
    
    for l = 1:L
    
    Zleft = zeros(size(test_data{1,l}.Zleftt,1),T);
    for t = (T1+(j-1)*2*T+T+1):(T1+(j-1)*2*T+T+T)
      [t,t-(j-1)*2*T-T-T1];
      for n = 1:size(test_data{1,l}.Zleftt,1)
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t - (j - 1)*2*T - T - T1) = 1;
          end
      end
    end
    Zleft_cout1(:,:,l,l_style) = Zleft;
    
    end
    j = 1+j;
end
j = 1;clear Zleft_cout2;clear Zright_cout2;clear Z_cout2;% cout2 for pre;
for l_style = 1:size(stimulus,2)
 for l = 1:L
    
    Zleft = zeros(size(test_data{1,l}.Zleftt,1),T);
    for t = (T1+(j-1)*2*T+1):(T1+(j-1)*2*T+T)
      
      for n = 1:size(test_data{1,l}.Zleftt,1)
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*2*T-T1) = 1;
          end
      end
    end
    Zleft_cout2(:,:,l,l_style) = Zleft;
 end
end


Zleft_spikingcount_pre = [];Zleft_spikingcount_post = [];
Q0=[];R10 = [];R20 = [];
for l_style = 1:size(stimulus,2)
 for l = 1:L
    Zleft_spikingcount_pre(:,l,l_style) = sum(Zleft_cout2(:,:,l,l_style),2);
    Zleft_spikingcount_post(:,l,l_style) = sum(Zleft_cout1(:,:,l,l_style),2);
    Q0(:,l,l_style) = Zleft_spikingcount_pre(:,l,l_style)./Zleft_spikingcount_post(:,l,l_style);
    for n = 1:size(Q0,1)
         if isnan(Q0(n,l,l_style))
             Q0(n,l,l_style) = 0;
         elseif isinf(Q0(n,l,l_style))
             Q0(n,l,l_style) = 0;
         end
    end
 end
end
Q=[];R = [];
for l_style = 1:size(stimulus,2)
   Q(:,l_style) = mean(Q0(:,:,l_style),2);
   R(:,l_style) = mean(Zleft_spikingcount_pre(:,:,l_style),2)./mean(Zleft_spikingcount_post(:,:,l_style),2);
   for n = 1:size(Q0,1)
         if isnan(R(n,l_style)) 
             R(n,l_style) = 0;
         elseif isinf(R(n,l_style))
             R(n,l_style) = 0;
         end
    end
end
p = [];
for l_style = 1:size(stimulus,2)
    for n_neuron = 1:size(Zleft_spikingcount_pre,1)
        X0 = Zleft_spikingcount_pre(n_neuron,:,l_style)';
        Y0 = Zleft_spikingcount_post(n_neuron,:,l_style)';
        B1 = cov(X0,Y0);
        p(n_neuron,l_style) = B1(2,2)/(std(X0)*std(Y0)); 
    end
end

for l_style = 1:size(stimulus,2)
    figure;
    Lim = 0;Min = 5;
    for n_neuron = 1:size(Zleft_spikingcount_pre,1)
        x0 = [];y0 = [];
        x0 = mean(Zleft_spikingcount_pre(n_neuron,:,l_style),2);
        y0 = mean(Zleft_spikingcount_post(n_neuron,:,l_style),2);
        
        if p(n_neuron,l_style) > 0
           plot(x0,y0,'*b');hold on;
           Lim = max(max(x0,y0),Lim);Min = min(min(x0,y0),Min);
%         else
%            plot(x0,y0,'oK');hold on;
        end
    end
    plot([0.8*Min,1.2*Lim],[0.8*Min,1.2*Lim],'--');
end

for l_style = 1:size(stimulus,2)
    figure;
    Lim = 0;Min = 5;
    for n_neuron = 1:size(Zleft_spikingcount_pre,1)
        x0 = [];y0 = [];
        x0 = Q(n_neuron,l_style);
        y0 = mean(Zleft_spikingcount_pre(n_neuron,:,l_style),2);
        
        if p(n_neuron,l_style) > 0
           plot(x0,y0,'*b');hold on;
           Lim = max(max(x0,y0),Lim);Min = min(min(x0,y0),Min);
%         else
%            plot(x0,y0,'oK');hold on;
        end
    end
    plot([1,1],[0.9*Min,1.2*Lim],'--');
end


for l_style = 1:size(stimulus,2)
    figure;
    Lim = 0;Min = 5;
    for n_neuron = 1:size(Zleft_spikingcount_pre,1)
        x0 = [];y0 = [];
        x0 = R(n_neuron,l_style);
        y0 = mean(Zleft_spikingcount_pre(n_neuron,:,l_style),2);
        
        if p(n_neuron,l_style) >= 0
           plot(x0,y0,'*b');hold on;
           Lim = max(max(x0,y0),Lim);Min = min(min(x0,y0),Min);
%         else
%            plot(x0,y0,'oK');hold on;
        end
    end
    plot([1,1],[0.9*Min,1.2*Lim],'--');
end

end