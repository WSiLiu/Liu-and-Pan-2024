function [p,p1] = probability_equaldistribution_clustering1(observe,clusteringset,p,significance,R,N_cue)

observe = observe(:,find(sum(observe)>0));  %observed data;
received_distance = zeros(N_cue,2);
p1 = p;

%���ڴ̼��еĸ���Դͷ���ֱ����̼��Ƿ�ͬԴ�ĸ��ʡ�
for j = 1:size(clusteringset,1) 
  for i = 1:2
  N1 = size(observe,2);N2 = size(clusteringset{j,i},2);
  U = [observe,clusteringset{j,i}];
  Edistance = zeros(1,R);
  for r = 1:R
    clear A1;clear B1;
    A1 = U(:,ceil(size(U,2)*rand(1,N1)));
    B1 = U(:,ceil(size(U,2)*rand(1,N2)));
    Edistance(1,r) = e_distance(A1,B1);
  end
  received_distance(j,i) = (1-significance)*max(Edistance(1,:));
  end
end 
Received_distance = 0.9*min(received_distance(:));

for j = 1:size(clusteringset,1)
   for i = 1:2
   Edistance1 = zeros(1,R);
   indicator = zeros(1,R);
   N1 = size(observe,2);N2 = size(clusteringset{j,i},2);
   U = [observe,clusteringset{j,i}];
   for r = 1:R
    clear A1;clear B1;
    A1 = U(:,ceil(size(U,2)*rand(1,N1)));
    B1 = U(:,ceil(size(U,2)*rand(1,N2)));
    Edistance1(1,r) = e_distance(A1,B1);
    indicator(1,r) = double(Edistance1(1,r)<=Received_distance);
    %indicator(2,r) = double(Edistance(l,r)<=Received_distance);
   end
   p(j,i) = sum(indicator(1,:))/R;
   end
end
end